from django.urls import path
from . import views
from .views import IndexView, ReportView

urlpatterns = [
    path('', IndexView.as_view(), name='home'),
    #path('',views.index, name='home'),
    path('second/',views.second),
    path('working/', views.working, name='working'),
    path('report/', views.report, name='report'),
    #path('index_log/',IndexView.as_view())
]

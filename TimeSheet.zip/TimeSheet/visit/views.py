from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.views import LoginView
from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin

# Create your views here.
class IndexView(LoginRequiredMixin, TemplateView):
    template_name = 'visit/index.html'
class ReportView(LoginRequiredMixin, TemplateView):
    template_name = 'visit/index.html'
def index(request):
    return render(request,'visit/index.html')
def second(request):
    return render(request, "visit/test.html")
def working(request):
    return render(request, "visit/lyaout.html")
def report(request):
    return render(request, "visit/test2.html")
